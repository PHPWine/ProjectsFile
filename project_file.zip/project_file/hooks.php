<?php 
/*

  $wine = new \PHPWineOptimizedHtml\Doctrine\Doctrine([
    those => '.class-name'
  ]); 

  print $wine->visible([

  ])->screen([
    
  ])->layout();
   

*/

function wine_those() : void {

  // Hide in tablet  
  $tablet = new \PHPWineOptimizedHtml\Doctrine\Doctrine([
   those => '.h-mble' 
  ]); 

  print $tablet->visible([
    'sm_mobile' => false
  ])->screen([
    'sm_mobile' => 540
  ])->layout();

  // Hide in mobile
  $desktop = new \PHPWineOptimizedHtml\Doctrine\Doctrine([
   those => '.h-dsktp' 
  ]); 

  print $desktop->visible([
    'xl_screen' => false
  ])->screen([
    'xl_screen' => 540
  ])->layout();
   
}