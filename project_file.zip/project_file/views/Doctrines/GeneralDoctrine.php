<?php namespace ProjectPro\Doctrines;?>
<?php  

class GeneralDoctrine {
 
   protected $wine;
   public function __construct()
   {
     $this->wine = new \PHPWineOptimizedHtml\OptimizedHtml();
   }

}