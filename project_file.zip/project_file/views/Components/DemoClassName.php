<?php namespace ProjectPro\Components;?>
<?php

use ProjectPro\Apps\DemoApp;

class DemoClassName extends DemoApp {

 // The Single source Content 
 private function content($person) {

    return [
      [h1, value=>["Hello People, $person!"]],
      [p, value=>["I am BackEnd Developer!"]]
    ];

  }
 
  // Desktop Content | This hide on tablet
  public function method_one($person) {

    return wine(div,[
      child=> $this->content($person)
    ],[
      classes => 'h-mble'
    ]);

  }

  // Mobile Content | Hide in desktop
  public function method_two() {

    return wine(div,[
      child=>$this->content('PHPWine')
    ],[
      classes=>'h-dsktp'
    ]); 
    
  }

}