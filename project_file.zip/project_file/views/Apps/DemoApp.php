<?php namespace ProjectPro\Apps;?>
<?php

use PHPWineOptimizedHtml\Doctrine\Doctrine;
use \ProjectPro\Doctrines\GeneralDoctrine;
use \ProjectPro\Components\DemoClassName;

class DemoApp extends GeneralDoctrine {

 public function app() {

    // This Doctrine class generate single div element!
    $demo = new Doctrine([
     attributes => [classes=>'l-content'],
     hooks => [
      xrow => [

        // This is call back for value and contents 
        [DemoClassName::class,'method_one',['PHP']], 
        [DemoClassName::class,'method_two']

      ]
     ],
    //  top_later => ['your_hook_name'],
    //  bottom_later => ['end_your_hook_name'] 
    ]);

    $demo = $demo->visible()->layout();

    return wine(section,$demo);

 }

}
